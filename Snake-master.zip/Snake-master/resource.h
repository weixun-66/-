//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resources.rc
//
#define IDI_ICON_GAME                   101
#define IDD_HELP_FORM                   101
#define IDR_GAME_START                  102
#define IDR_EATING                      103
#define IDR_READY                       104
#define IDR_GO                          105
#define IDR_NEXT                        106
#define IDR_GAME_OVER                   107
#define IDD_GAMEOVER_DLG                108
#define IDC_BTN_OK                      1000
#define IDC_GAME_AGAIN                  1001
#define IDC_RETURN_MAIN                 1002
#define IDC_EXIT_GAME                   1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
